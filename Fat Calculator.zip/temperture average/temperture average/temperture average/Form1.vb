﻿Public Class Form1

    'jeffrey hagan  
    'vb for business
    'temperture average pt 2

    Dim dblIntTempInput1 As Short
    Dim dblIntTempInput2 As Short
    Dim dblIntTempInput3 As Short
    Dim dblIntTempInput4 As Short
    Dim dblIntTempInput5 As Short
    Dim dblHold As Short
    Dim dblTotal As Short



    Private Sub btnRun_Click(sender As Object, e As EventArgs) Handles btnRun.Click


        'seris of nested loops to checj each textbox and make sure each input is a number and between -50 and 130
        'if tryparse returns false on anyone of the criteria(numerical and between -50 nad 130) is will display message box saying user needs to enter number and between range
        If Short.TryParse(txt1.Text, dblIntTempInput1) And dblIntTempInput1 > -50 And dblIntTempInput1 < 130 Then
            If Short.TryParse(txt2.Text, dblIntTempInput2) And dblIntTempInput2 > -50 And dblIntTempInput2 < 130 Then
                If Short.TryParse(txt3.Text, dblIntTempInput3) And dblIntTempInput3 > -50 And dblIntTempInput3 < 130 Then
                    If Short.TryParse(txt4.Text, dblIntTempInput4) And dblIntTempInput4 > -50 And dblIntTempInput4 < 130 Then
                        If Short.TryParse(txt5.Text, dblIntTempInput5) And dblIntTempInput5 > -50 And dblIntTempInput5 < 130 Then

                            dblTotal = dblIntTempInput1 + dblIntTempInput2 + dblIntTempInput3 + dblIntTempInput4 + dblIntTempInput5
                            dblHold = dblTotal / 5
                            lblAverageReults.Text = dblHold


                        Else
                            ToolStripStatusLabel1.Text = "please fix error in week 5"
                            txt5.Focus()
                            MsgBox("please enter numbers between -50 and 130")
                        End If
                    Else
                        ToolStripStatusLabel1.Text = "please fix error in week 4"
                        txt4.Focus()
                        MsgBox("please enter numbers between -50 and 130")
                    End If
                Else
                    ToolStripStatusLabel1.Text = "please fix error in week 3"
                    txt3.Focus()
                    MsgBox("please enter numbers between -50 and 130")
                End If
            Else
                ToolStripStatusLabel1.Text = "please fix error in week 2"
                txt2.Focus()
                MsgBox("please enter numbers between -50 and 130")
            End If
        Else
            ToolStripStatusLabel1.Text = "please fix error in week 1"
            txt1.Focus()
            MsgBox("please enter numbers between -50 and 130")


        End If




    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txt1.Text = ""
        txt2.Text = ""
        txt3.Text = ""
        txt4.Text = ""
        txt5.Text = ""
        lblAverageReults.Text = ""
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub
End Class
