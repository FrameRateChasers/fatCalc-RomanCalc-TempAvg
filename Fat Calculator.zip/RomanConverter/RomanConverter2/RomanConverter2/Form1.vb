﻿Public Class Form1


	'JEFFREY HAGAN
	'VB FOR BUSINESS
	'ROMAN CONVERTER
	'2/20/18
	Private Sub btnRun_Click(sender As Object, e As EventArgs) Handles btnRun.Click

		'declare varible to hold input in textbox
		Dim strDecInput As String = txtDecNumInput.Text

		'if user press any number form 1-10 it will output roman numeral in label 
		Select Case strDecInput
			Case 1
				lblRomanNumOutput.Text = "I"
			Case 2
				lblRomanNumOutput.Text = "II"
			Case 3
				lblRomanNumOutput.Text = "III"
			Case 4
				lblRomanNumOutput.Text = "IV"
			Case 5
				lblRomanNumOutput.Text = "V"
			Case 6
				lblRomanNumOutput.Text = "VI"
			Case 7
				lblRomanNumOutput.Text = "VII"
			Case 8
				lblRomanNumOutput.Text = "VIII"
			Case 9
				lblRomanNumOutput.Text = "IX"
			Case 10
				lblRomanNumOutput.Text = "X"
			Case Else
				MsgBox("Please enter decimal numbers 1 through 10", MsgBoxStyle.Critical)
		End Select

	End Sub

	Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click

		'clear all inputs
		txtDecNumInput.Text = ""
		lblRomanNumOutput.Text = ""
	End Sub

	Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
		Me.Close()
	End Sub
End Class
