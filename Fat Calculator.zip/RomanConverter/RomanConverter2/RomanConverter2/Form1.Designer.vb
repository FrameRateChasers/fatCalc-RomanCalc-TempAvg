﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.btnRun = New System.Windows.Forms.Button()
		Me.btnClear = New System.Windows.Forms.Button()
		Me.btnExit = New System.Windows.Forms.Button()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.lblRomanNumOutput = New System.Windows.Forms.Label()
		Me.txtDecNumInput = New System.Windows.Forms.TextBox()
		Me.SuspendLayout()
		'
		'btnRun
		'
		Me.btnRun.Location = New System.Drawing.Point(24, 254)
		Me.btnRun.Name = "btnRun"
		Me.btnRun.Size = New System.Drawing.Size(121, 45)
		Me.btnRun.TabIndex = 0
		Me.btnRun.Text = "RUN"
		Me.btnRun.UseVisualStyleBackColor = True
		'
		'btnClear
		'
		Me.btnClear.Location = New System.Drawing.Point(189, 254)
		Me.btnClear.Name = "btnClear"
		Me.btnClear.Size = New System.Drawing.Size(121, 45)
		Me.btnClear.TabIndex = 1
		Me.btnClear.Text = "CLEAR"
		Me.btnClear.UseVisualStyleBackColor = True
		'
		'btnExit
		'
		Me.btnExit.Location = New System.Drawing.Point(343, 254)
		Me.btnExit.Name = "btnExit"
		Me.btnExit.Size = New System.Drawing.Size(121, 45)
		Me.btnExit.TabIndex = 2
		Me.btnExit.Text = "EXIT"
		Me.btnExit.UseVisualStyleBackColor = True
		'
		'Label1
		'
		Me.Label1.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label1.Location = New System.Drawing.Point(21, 52)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(174, 44)
		Me.Label1.TabIndex = 3
		Me.Label1.Text = "Enter decimal range from 1 to 10"
		'
		'Label2
		'
		Me.Label2.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Label2.Location = New System.Drawing.Point(21, 147)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(174, 50)
		Me.Label2.TabIndex = 4
		Me.Label2.Text = "Equivalent roman numeral"
		'
		'lblRomanNumOutput
		'
		Me.lblRomanNumOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
		Me.lblRomanNumOutput.Font = New System.Drawing.Font("Verdana", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.lblRomanNumOutput.Location = New System.Drawing.Point(212, 147)
		Me.lblRomanNumOutput.Name = "lblRomanNumOutput"
		Me.lblRomanNumOutput.Size = New System.Drawing.Size(133, 36)
		Me.lblRomanNumOutput.TabIndex = 6
		'
		'txtDecNumInput
		'
		Me.txtDecNumInput.Location = New System.Drawing.Point(212, 64)
		Me.txtDecNumInput.Name = "txtDecNumInput"
		Me.txtDecNumInput.Size = New System.Drawing.Size(137, 20)
		Me.txtDecNumInput.TabIndex = 7
		'
		'Form1
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(480, 311)
		Me.Controls.Add(Me.txtDecNumInput)
		Me.Controls.Add(Me.lblRomanNumOutput)
		Me.Controls.Add(Me.Label2)
		Me.Controls.Add(Me.Label1)
		Me.Controls.Add(Me.btnExit)
		Me.Controls.Add(Me.btnClear)
		Me.Controls.Add(Me.btnRun)
		Me.Name = "Form1"
		Me.Text = "Roman Converter"
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents btnRun As Button
	Friend WithEvents btnClear As Button
	Friend WithEvents btnExit As Button
	Friend WithEvents Label1 As Label
	Friend WithEvents Label2 As Label
	Friend WithEvents lblRomanNumOutput As Label
	Friend WithEvents txtDecNumInput As TextBox
End Class
