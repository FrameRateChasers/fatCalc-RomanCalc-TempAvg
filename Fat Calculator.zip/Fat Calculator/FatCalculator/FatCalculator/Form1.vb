﻿Public Class Form1

    'JEFFREY HAGAN
    'VB FOR BUSINESS
    'FAT CALCULATOR

    'CONSTANT VARIBLE
    Const GRAM_OF_FAT As Double = 9

    'GLOBAL VARIBLES
    Dim dblNumCalInFood As Double
    Dim dblNumFatInFood As Double
    Dim dblPercentOutput As Double
    Private Sub btnRun_Click(sender As Object, e As EventArgs) Handles btnRun.Click

        'THE FIRST IF STATEMENT CHECKS IF BOTH  TWO INPUTS ARE NUMBERS
        'IF THEY ARE BOTH TRUE THEN STATEMENT IS TRUE AND THEN CONVERTS USER INPUT INTO DOUBLES
        'AND PLACES THEM INTO DECLARED VARIBLE

        If IsNumeric(txtNumCalFood.Text) And IsNumeric(txtNumFatGram.Text) Then

            'CONVERSION
            dblNumCalInFood = CDbl(txtNumCalFood.Text)
            dblNumFatInFood = CDbl(txtNumFatGram.Text)

            'THEN IF BOTH OF THE DOUBLE VARIBLES ARE GREATER THAN ZERO STATMENT WILL BE TRUE
            ' WHICH WILL THEN FIND PERCENTAGE OF FAT FROM CALORIES AND SAVE IT TO VARIBLE FOR PERCENTAGE

            If (dblNumCalInFood >= 1 And dblNumFatInFood >= 1) Then
                dblPercentOutput = (dblNumFatInFood * GRAM_OF_FAT) / dblNumCalInFood

                'IF THE PERCENTAGE IS LESS THAN 30 IT WILL ALERT USER THAT THE FOOD IS LOW IN FAT AND DISPLAY PERCENTAGE.
                'IF PERCENTAGE IS GREATER THAN OR EQULA TO 30 THEN IT WILL ONLY DISPLAY PERCENATAGE.

                If (dblPercentOutput <= 0.29) Then
                    MsgBox("This food is low in fat", MsgBoxStyle.Critical)
                    lblPercentOutput.Text = dblPercentOutput.ToString("P")
                ElseIf (dblPercentOutput > 0.3) Then
                    lblPercentOutput.Text = dblPercentOutput.ToString("P")
                End If
            Else

                'IF INPUT ARE NOT GREATER THAN 0

                MsgBox("Must be greater than 0", MsgBoxStyle.Critical)
            End If
        Else
            'IF INPUT ARE NOT NUMBERIC

            MsgBox("Must be numeric digit", MsgBoxStyle.Critical)
        End If


    End Sub

    Private Sub btnCleaer_Click(sender As Object, e As EventArgs) Handles btnCleaer.Click
        txtNumFatGram.Text = ""
        txtNumCalFood.Text = ""
        lblPercentOutput.Text = ""
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
