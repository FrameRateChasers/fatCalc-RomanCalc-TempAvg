﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnRun = New System.Windows.Forms.Button()
        Me.btnCleaer = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblPercentOutput = New System.Windows.Forms.Label()
        Me.txtNumCalFood = New System.Windows.Forms.TextBox()
        Me.txtNumFatGram = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnRun
        '
        Me.btnRun.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRun.Location = New System.Drawing.Point(28, 270)
        Me.btnRun.Name = "btnRun"
        Me.btnRun.Size = New System.Drawing.Size(110, 45)
        Me.btnRun.TabIndex = 0
        Me.btnRun.Text = "RUN"
        Me.btnRun.UseVisualStyleBackColor = True
        '
        'btnCleaer
        '
        Me.btnCleaer.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCleaer.Location = New System.Drawing.Point(170, 270)
        Me.btnCleaer.Name = "btnCleaer"
        Me.btnCleaer.Size = New System.Drawing.Size(110, 45)
        Me.btnCleaer.TabIndex = 1
        Me.btnCleaer.Text = "CLEAR"
        Me.btnCleaer.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(308, 270)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(110, 45)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "EXIT"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(25, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(220, 39)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Enter number of calories in food"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(25, 106)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(254, 40)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Enter number of fat grams in food"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(25, 170)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(260, 53)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Percentage of calories that come from fat"
        '
        'lblPercentOutput
        '
        Me.lblPercentOutput.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPercentOutput.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPercentOutput.Location = New System.Drawing.Point(316, 170)
        Me.lblPercentOutput.Name = "lblPercentOutput"
        Me.lblPercentOutput.Size = New System.Drawing.Size(104, 45)
        Me.lblPercentOutput.TabIndex = 6
        '
        'txtNumCalFood
        '
        Me.txtNumCalFood.Location = New System.Drawing.Point(316, 33)
        Me.txtNumCalFood.Name = "txtNumCalFood"
        Me.txtNumCalFood.Size = New System.Drawing.Size(102, 20)
        Me.txtNumCalFood.TabIndex = 7
        '
        'txtNumFatGram
        '
        Me.txtNumFatGram.Location = New System.Drawing.Point(316, 106)
        Me.txtNumFatGram.Name = "txtNumFatGram"
        Me.txtNumFatGram.Size = New System.Drawing.Size(102, 20)
        Me.txtNumFatGram.TabIndex = 8
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(476, 343)
        Me.Controls.Add(Me.txtNumFatGram)
        Me.Controls.Add(Me.txtNumCalFood)
        Me.Controls.Add(Me.lblPercentOutput)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCleaer)
        Me.Controls.Add(Me.btnRun)
        Me.Name = "Form1"
        Me.Text = "Fat Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnRun As Button
    Friend WithEvents btnCleaer As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblPercentOutput As Label
    Friend WithEvents txtNumCalFood As TextBox
    Friend WithEvents txtNumFatGram As TextBox
End Class
